package com.example.shamanth.facecon;


public class Config {
    // File upload url (replace the ip with your server address)
    public static final String FILE_UPLOAD_URL = "https://backendmcc.herokuapp.com/uploadImage";

    // Directory name to store captured images and videos
    public static final String IMAGE_DIRECTORY_NAME = "Android File Upload";
}
